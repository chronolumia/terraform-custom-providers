## Example: Datasource Infoblox Network

This example provisions the following Resources:

- `infoblox_network`

## Outputs

1. ID
2. Name

## Usage

- Refresh with `terraform apply`
